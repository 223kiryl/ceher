import glob
import zipfile
import requests
import re
import asyncio
import shutil
import os
from bs4 import BeautifulSoup
from http.cookiejar import MozillaCookieJar
from http.cookiejar import LoadError
from typing import TextIO


class ArchiveExtractor:

    def __init__(self, zip_path):
        self.zip_path = zip_path

    @property
    def zip_name(self):
        return self.zip_path.replace(f'archives{os.sep}', '').replace('.zip', '')

    def extract_zip_by_path(self):
        with zipfile.ZipFile(self.zip_path, 'r') as zip_worker:
            self.extract_zip_with_cookies(zip_worker=zip_worker)
            return self.zip_name

    def extract_zip_with_cookies(self, zip_worker: zipfile.ZipFile):
        for filename in zip_worker.infolist():
            if filename.filename[-1] == f'/':
                continue
            if 'Cookies' in filename.filename:
                filename.filename = os.path.basename(filename.filename)
                zip_worker.extract(filename, os.path.join('cookies_files', 'Cookies'))


class Cookie:
    def __init__(self, cookie_path):
        self.cookie_path = cookie_path
        self.cookie_name = cookie_path.split(f'{os.sep}')[-1].replace('.txt', '')
        self.header = """\
# Netscape HTTP Cookie File
# http://curl.haxx.se/rfc/cookie_spec.html
# This is a generated file!  Do not edit.\n"""

    def open_read_cookie(self) -> TextIO:
        return open(self.cookie_path, encoding='utf-8')

    def write_cookie(self, text):
        open(self.cookie_path, 'w', encoding='utf-8').write(text)

    def open_add_cookie(self) -> TextIO:
        return open(self.cookie_path, 'a', encoding='utf-8')

    def cookie_jar(self):
        # TODO: Подумать как можно сделать лучше и красивее
        self.put_header()
        cookie_jar = MozillaCookieJar(self.cookie_path)
        try:
            cookie_jar.load()
        except LoadError:
            self.put_dots()
            cookie_jar.load()
        return cookie_jar

    def normalize_cookie(self):
        self.put_dots()
        self.put_header()

    def is_cookie_have_dots(self) -> bool:
        for line in self.open_read_cookie().readlines()[3:]:
            if line.startswith('.'):
                return True
        return False

    def put_dots(self):
        cookie_lines = self.open_read_cookie().readlines()
        for line in cookie_lines:
            if not line.startswith('#') and not line.startswith('.'):
                cookie_lines[cookie_lines.index(line)] = f'.{line}'
        self.write_cookie(''.join(cookie_lines))

    def put_header(self):
        old_cookie = self.open_read_cookie().read()  # TODO: Придумать другое имя перемменой
        if not self.is_cookies_have_header():
            self.write_cookie(self.header + old_cookie)

    def is_cookies_have_header(self) -> bool:
        return self.header in self.open_read_cookie().read()


class Account:
    def __init__(self, bs4_page):
        self.bs4_page = bs4_page
        self.tag_list = self.get_channels()

    def get_count_of_channels(self) -> int:
        return len(self.tag_list) // 2

    def get_sum_subs(self) -> int:
        try:
            subs = [
                int((re.findall(r'\d+,\d+', tag.contents[0])[0]).replace(',', '')) if not 'gmail' in tag.contents[0] else 0
                for tag in
                self.tag_list if
                self.tag_list.index(tag) % 2 == 0]

            return sum(subs)
        except IndexError:
            return 0

    def get_sum_videos(self) -> int:
        try:
            videos = [int((re.findall(r'\d+,\d+', tag.contents[0])[0]).replace(',', '')) for tag in self.tag_list if
                      self.tag_list.index(tag) % 2 != 0]
            return sum(videos)
        except IndexError:
            return 0

    def get_channels(self):
        return self.bs4_page.find_all('div', class_='page-info-text')

    def get_account_status(self) -> str:
        if re.findall("https://accounts.google.com/SignUpWithoutGmail", str(self.bs4_page)):
            return 'Требуется авторизация'
        return 'Каналов нет на аккаунте' if self.get_count_of_channels() == 0 else 'В норме'

    def get_full_account_stat(self, name_zip=None, name_cookie=None):
        return f'[{name_zip}]({name_cookie})| Общее количество подписчиков: {self.get_sum_subs()}| ' \
               f'Общее количество видео: {self.get_sum_videos()}| ' \
               f'Количество каналов: {self.get_count_of_channels()}| ' \
               f'{self.get_account_status()}'


class ChannelUploader:

    def __init__(self, cookie_obj):
        self.cookie = cookie_obj
        self.page = self.get_page(cookie_obj.cookie_jar())
        self.bs4_page = self.get_bs4_page()

    @property
    def account(self):
        account = Account(self.bs4_page)
        return account

    def get_page(self, cookie_jar) -> str:
        res = requests.get(url='https://www.youtube.com/channel_switcher', cookies=cookie_jar).text
        return res

    def get_bs4_page(self):
        return BeautifulSoup(self.page, 'html.parser')

# a = ArchiveExtractor('archives/3440_1_PK-2020-01-01 10-10-55711314BF-86C3DFC7-686.zip')
# a.extract_zip_by_path()
# cookie = Cookie('cookies_files/Cookies/GoogleChrome_Profile archives.txt')
# cookie.cookie_jar()
# ch = ChannelUploader(cookie)
# print(ch.account.get_full_account_stat())
