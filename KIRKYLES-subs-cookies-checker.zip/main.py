import datetime
import glob
import os
import shutil
from http.cookiejar import LoadError

import pandas as pd

from core import Cookie, ChannelUploader, ArchiveExtractor


class CookieChecker:

    def __init__(self):
        self.error_count = 0
        self.datetime_now = datetime.datetime.now().strftime("%Y-%m-%d-%H-%M-%S")
        self.df = pd.DataFrame({'subs': [], 'videos': [], 'channels': [], 'zip_name': [], 'cookie_name': []})
        self.sum_subs = 0

    @property
    def all_zips(self):
        return glob.glob(os.path.join('archives', '*.zip'))

    @property
    def all_cookies(self):
        return glob.glob(os.path.join('cookies_files', 'Cookies', '*.txt'))

    def unpack_zip(self, zip_path):
        archive = ArchiveExtractor(zip_path)
        archive_name = archive.extract_zip_by_path()
        return archive_name

    # TODO:Подумать как декомпозировать эти два метода
    def polling(self):
        for zip_path in self.all_zips:
            zip_name = self.unpack_zip(zip_path)
            self.print_accounts(zip_name)
            self.remove_cookies_dir()
            self.rename_result_dir(zip_name)

    def print_accounts(self, zip_name):
        for cookie_path in self.all_cookies:
            try:
                cookie_obj = Cookie(cookie_path)
                account = ChannelUploader(cookie_obj).account
                account_stat = account.get_full_account_stat(zip_name, cookie_obj.cookie_name)
                print(account_stat)
                self.write_log(account_stat)
                self.sum_subs += account.get_sum_subs()
                self.move_cookie_to_dir(cookie_path, zip_name, account, cookie_obj.cookie_name)
                self.append_to_excel(account, zip_name, cookie_obj.cookie_name)
            except LoadError as err:
                self.error_count += 1

    def write_log(self, account_stat):
        self.create_dir('logs')
        open(os.path.join('logs', f'log_{self.datetime_now}'), 'a', encoding='utf-8').write(f'{account_stat}\n')

    def move_cookie_to_dir(self, cookie_path, destination_dirname, account, cookie_name):
        destination_dirname = f'{destination_dirname}'
        self.create_dir_for_cookies(destination_dirname)
        new_cookie_name = f'{cookie_name}_subs{account.get_sum_subs()}_' \
                          f'videos{account.get_sum_videos()}_channels{account.get_count_of_channels()}.txt'
        try:
            os.rename(cookie_path, os.path.join(f'result_cookies', f'{destination_dirname}', new_cookie_name))
        except FileExistsError:
            pass

    def create_dir_for_cookies(self, dirname):
        self.create_dir('result_cookies')
        self.create_dir(os.path.join('result_cookies', dirname))

    def rename_result_dir(self, dir_name):
        source_path = os.path.join('result_cookies', dir_name)
        destination_path = os.path.join('result_cookies', f'{self.sum_subs}_{dir_name}')
        try:
            os.rename(source_path, destination_path)
        except OSError:
            pass
        self.sum_subs = 0

    def create_dir(self, dirname):
        try:
            os.mkdir(dirname)
        except FileExistsError:
            pass

    def remove_cookies_dir(self):
        shutil.rmtree(os.path.join('cookies_files', 'Cookies'))

    def append_to_excel(self, account, zip_name, cookie_name):
        line = {'subs': account.get_sum_subs(), 'videos': account.get_sum_videos(),
                'channels': account.get_count_of_channels(), 'account_status': account.get_account_status(),
                'zip_name': zip_name, 'cookie_name': cookie_name}
        self.df = self.df.append([line], ignore_index=True)


if __name__ == '__main__':
    checker = CookieChecker()
    checker.polling()
    checker.df.to_excel(os.path.join(f'logs', f'excel_log{checker.datetime_now}.xls'))
